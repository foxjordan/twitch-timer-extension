import{c as Gt,j as p,r as w}from"./client-B_pnGUEq.js";const Kt=()=>{};var He={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ct=function(e){const t=[];let n=0;for(let r=0;r<e.length;r++){let a=e.charCodeAt(r);a<128?t[n++]=a:a<2048?(t[n++]=a>>6|192,t[n++]=a&63|128):(a&64512)===55296&&r+1<e.length&&(e.charCodeAt(r+1)&64512)===56320?(a=65536+((a&1023)<<10)+(e.charCodeAt(++r)&1023),t[n++]=a>>18|240,t[n++]=a>>12&63|128,t[n++]=a>>6&63|128,t[n++]=a&63|128):(t[n++]=a>>12|224,t[n++]=a>>6&63|128,t[n++]=a&63|128)}return t},Jt=function(e){const t=[];let n=0,r=0;for(;n<e.length;){const a=e[n++];if(a<128)t[r++]=String.fromCharCode(a);else if(a>191&&a<224){const s=e[n++];t[r++]=String.fromCharCode((a&31)<<6|s&63)}else if(a>239&&a<365){const s=e[n++],i=e[n++],o=e[n++],c=((a&7)<<18|(s&63)<<12|(i&63)<<6|o&63)-65536;t[r++]=String.fromCharCode(55296+(c>>10)),t[r++]=String.fromCharCode(56320+(c&1023))}else{const s=e[n++],i=e[n++];t[r++]=String.fromCharCode((a&15)<<12|(s&63)<<6|i&63)}}return t.join("")},lt={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const n=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,r=[];for(let a=0;a<e.length;a+=3){const s=e[a],i=a+1<e.length,o=i?e[a+1]:0,c=a+2<e.length,l=c?e[a+2]:0,h=s>>2,u=(s&3)<<4|o>>4;let m=(o&15)<<2|l>>6,F=l&63;c||(F=64,i||(m=64)),r.push(n[h],n[u],n[m],n[F])}return r.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(ct(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):Jt(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();const n=t?this.charToByteMapWebSafe_:this.charToByteMap_,r=[];for(let a=0;a<e.length;){const s=n[e.charAt(a++)],o=a<e.length?n[e.charAt(a)]:0;++a;const l=a<e.length?n[e.charAt(a)]:64;++a;const u=a<e.length?n[e.charAt(a)]:64;if(++a,s==null||o==null||l==null||u==null)throw new Yt;const m=s<<2|o>>4;if(r.push(m),l!==64){const F=o<<4&240|l>>2;if(r.push(F),u!==64){const N=l<<6&192|u;r.push(N)}}}return r},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class Yt extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const Xt=function(e){const t=ct(e);return lt.encodeByteArray(t,!0)},dt=function(e){return Xt(e).replace(/\./g,"")},Zt=function(e){try{return lt.decodeString(e,!0)}catch(t){console.error("base64Decode failed: ",t)}return null};/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qt(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const en=()=>Qt().__FIREBASE_DEFAULTS__,tn=()=>{if(typeof process>"u"||typeof He>"u")return;const e=He.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},nn=()=>{if(typeof document>"u")return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const t=e&&Zt(e[1]);return t&&JSON.parse(t)},rn=()=>{try{return Kt()||en()||tn()||nn()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},ut=()=>{var e;return(e=rn())==null?void 0:e.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class an{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((t,n)=>{this.resolve=t,this.reject=n})}wrapCallback(t){return(n,r)=>{n?this.reject(n):this.resolve(r),typeof t=="function"&&(this.promise.catch(()=>{}),t.length===1?t(n):t(n,r))}}}function ft(){const e=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof e=="object"&&e.id!==void 0}function me(){try{return typeof indexedDB=="object"}catch{return!1}}function ge(){return new Promise((e,t)=>{try{let n=!0;const r="validate-browser-context-for-indexeddb-analytics-module",a=self.indexedDB.open(r);a.onsuccess=()=>{a.result.close(),n||self.indexedDB.deleteDatabase(r),e(!0)},a.onupgradeneeded=()=>{n=!1},a.onerror=()=>{var s;t(((s=a.error)==null?void 0:s.message)||"")}}catch(n){t(n)}})}function ht(){return!(typeof navigator>"u"||!navigator.cookieEnabled)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const sn="FirebaseError";class P extends Error{constructor(t,n,r){super(n),this.code=t,this.customData=r,this.name=sn,Object.setPrototypeOf(this,P.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,X.prototype.create)}}class X{constructor(t,n,r){this.service=t,this.serviceName=n,this.errors=r}create(t,...n){const r=n[0]||{},a=`${this.service}/${t}`,s=this.errors[t],i=s?on(s,r):"Error",o=`${this.serviceName}: ${i} (${a}).`;return new P(a,o,r)}}function on(e,t){return e.replace(cn,(n,r)=>{const a=t[r];return a!=null?String(a):`<${r}?>`})}const cn=/\{\$([^}]+)}/g;function G(e,t){if(e===t)return!0;const n=Object.keys(e),r=Object.keys(t);for(const a of n){if(!r.includes(a))return!1;const s=e[a],i=t[a];if(ze(s)&&ze(i)){if(!G(s,i))return!1}else if(s!==i)return!1}for(const a of r)if(!n.includes(a))return!1;return!0}function ze(e){return e!==null&&typeof e=="object"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ln=1e3,dn=2,un=4*60*60*1e3,fn=.5;function Ve(e,t=ln,n=dn){const r=t*Math.pow(n,e),a=Math.round(fn*r*(Math.random()-.5)*2);return Math.min(un,r+a)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function be(e){return e&&e._delegate?e._delegate:e}class R{constructor(t,n,r){this.name=t,this.instanceFactory=n,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(t){return this.instantiationMode=t,this}setMultipleInstances(t){return this.multipleInstances=t,this}setServiceProps(t){return this.serviceProps=t,this}setInstanceCreatedCallback(t){return this.onInstanceCreated=t,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const O="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hn{constructor(t,n){this.name=t,this.container=n,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(t){const n=this.normalizeInstanceIdentifier(t);if(!this.instancesDeferred.has(n)){const r=new an;if(this.instancesDeferred.set(n,r),this.isInitialized(n)||this.shouldAutoInitialize())try{const a=this.getOrInitializeService({instanceIdentifier:n});a&&r.resolve(a)}catch{}}return this.instancesDeferred.get(n).promise}getImmediate(t){const n=this.normalizeInstanceIdentifier(t==null?void 0:t.identifier),r=(t==null?void 0:t.optional)??!1;if(this.isInitialized(n)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:n})}catch(a){if(r)return null;throw a}else{if(r)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(t){if(t.name!==this.name)throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=t,!!this.shouldAutoInitialize()){if(mn(t))try{this.getOrInitializeService({instanceIdentifier:O})}catch{}for(const[n,r]of this.instancesDeferred.entries()){const a=this.normalizeInstanceIdentifier(n);try{const s=this.getOrInitializeService({instanceIdentifier:a});r.resolve(s)}catch{}}}}clearInstance(t=O){this.instancesDeferred.delete(t),this.instancesOptions.delete(t),this.instances.delete(t)}async delete(){const t=Array.from(this.instances.values());await Promise.all([...t.filter(n=>"INTERNAL"in n).map(n=>n.INTERNAL.delete()),...t.filter(n=>"_delete"in n).map(n=>n._delete())])}isComponentSet(){return this.component!=null}isInitialized(t=O){return this.instances.has(t)}getOptions(t=O){return this.instancesOptions.get(t)||{}}initialize(t={}){const{options:n={}}=t,r=this.normalizeInstanceIdentifier(t.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const a=this.getOrInitializeService({instanceIdentifier:r,options:n});for(const[s,i]of this.instancesDeferred.entries()){const o=this.normalizeInstanceIdentifier(s);r===o&&i.resolve(a)}return a}onInit(t,n){const r=this.normalizeInstanceIdentifier(n),a=this.onInitCallbacks.get(r)??new Set;a.add(t),this.onInitCallbacks.set(r,a);const s=this.instances.get(r);return s&&t(s,r),()=>{a.delete(t)}}invokeOnInitCallbacks(t,n){const r=this.onInitCallbacks.get(n);if(r)for(const a of r)try{a(t,n)}catch{}}getOrInitializeService({instanceIdentifier:t,options:n={}}){let r=this.instances.get(t);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:pn(t),options:n}),this.instances.set(t,r),this.instancesOptions.set(t,n),this.invokeOnInitCallbacks(r,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,r)}catch{}return r||null}normalizeInstanceIdentifier(t=O){return this.component?this.component.multipleInstances?t:O:t}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function pn(e){return e===O?void 0:e}function mn(e){return e.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gn{constructor(t){this.name=t,this.providers=new Map}addComponent(t){const n=this.getProvider(t.name);if(n.isComponentSet())throw new Error(`Component ${t.name} has already been registered with ${this.name}`);n.setComponent(t)}addOrOverwriteComponent(t){this.getProvider(t.name).isComponentSet()&&this.providers.delete(t.name),this.addComponent(t)}getProvider(t){if(this.providers.has(t))return this.providers.get(t);const n=new hn(t,this);return this.providers.set(t,n),n}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var d;(function(e){e[e.DEBUG=0]="DEBUG",e[e.VERBOSE=1]="VERBOSE",e[e.INFO=2]="INFO",e[e.WARN=3]="WARN",e[e.ERROR=4]="ERROR",e[e.SILENT=5]="SILENT"})(d||(d={}));const bn={debug:d.DEBUG,verbose:d.VERBOSE,info:d.INFO,warn:d.WARN,error:d.ERROR,silent:d.SILENT},yn=d.INFO,wn={[d.DEBUG]:"log",[d.VERBOSE]:"log",[d.INFO]:"info",[d.WARN]:"warn",[d.ERROR]:"error"},In=(e,t,...n)=>{if(t<e.logLevel)return;const r=new Date().toISOString(),a=wn[t];if(a)console[a](`[${r}]  ${e.name}:`,...n);else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class pt{constructor(t){this.name=t,this._logLevel=yn,this._logHandler=In,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(t){if(!(t in d))throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);this._logLevel=t}setLogLevel(t){this._logLevel=typeof t=="string"?bn[t]:t}get logHandler(){return this._logHandler}set logHandler(t){if(typeof t!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=t}get userLogHandler(){return this._userLogHandler}set userLogHandler(t){this._userLogHandler=t}debug(...t){this._userLogHandler&&this._userLogHandler(this,d.DEBUG,...t),this._logHandler(this,d.DEBUG,...t)}log(...t){this._userLogHandler&&this._userLogHandler(this,d.VERBOSE,...t),this._logHandler(this,d.VERBOSE,...t)}info(...t){this._userLogHandler&&this._userLogHandler(this,d.INFO,...t),this._logHandler(this,d.INFO,...t)}warn(...t){this._userLogHandler&&this._userLogHandler(this,d.WARN,...t),this._logHandler(this,d.WARN,...t)}error(...t){this._userLogHandler&&this._userLogHandler(this,d.ERROR,...t),this._logHandler(this,d.ERROR,...t)}}const En=(e,t)=>t.some(n=>e instanceof n);let Ue,We;function Sn(){return Ue||(Ue=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function _n(){return We||(We=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const mt=new WeakMap,le=new WeakMap,gt=new WeakMap,ne=new WeakMap,ye=new WeakMap;function An(e){const t=new Promise((n,r)=>{const a=()=>{e.removeEventListener("success",s),e.removeEventListener("error",i)},s=()=>{n(C(e.result)),a()},i=()=>{r(e.error),a()};e.addEventListener("success",s),e.addEventListener("error",i)});return t.then(n=>{n instanceof IDBCursor&&mt.set(n,e)}).catch(()=>{}),ye.set(t,e),t}function Tn(e){if(le.has(e))return;const t=new Promise((n,r)=>{const a=()=>{e.removeEventListener("complete",s),e.removeEventListener("error",i),e.removeEventListener("abort",i)},s=()=>{n(),a()},i=()=>{r(e.error||new DOMException("AbortError","AbortError")),a()};e.addEventListener("complete",s),e.addEventListener("error",i),e.addEventListener("abort",i)});le.set(e,t)}let de={get(e,t,n){if(e instanceof IDBTransaction){if(t==="done")return le.get(e);if(t==="objectStoreNames")return e.objectStoreNames||gt.get(e);if(t==="store")return n.objectStoreNames[1]?void 0:n.objectStore(n.objectStoreNames[0])}return C(e[t])},set(e,t,n){return e[t]=n,!0},has(e,t){return e instanceof IDBTransaction&&(t==="done"||t==="store")?!0:t in e}};function Cn(e){de=e(de)}function Dn(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(t,...n){const r=e.call(re(this),t,...n);return gt.set(r,t.sort?t.sort():[t]),C(r)}:_n().includes(e)?function(...t){return e.apply(re(this),t),C(mt.get(this))}:function(...t){return C(e.apply(re(this),t))}}function vn(e){return typeof e=="function"?Dn(e):(e instanceof IDBTransaction&&Tn(e),En(e,Sn())?new Proxy(e,de):e)}function C(e){if(e instanceof IDBRequest)return An(e);if(ne.has(e))return ne.get(e);const t=vn(e);return t!==e&&(ne.set(e,t),ye.set(t,e)),t}const re=e=>ye.get(e);function bt(e,t,{blocked:n,upgrade:r,blocking:a,terminated:s}={}){const i=indexedDB.open(e,t),o=C(i);return r&&i.addEventListener("upgradeneeded",c=>{r(C(i.result),c.oldVersion,c.newVersion,C(i.transaction),c)}),n&&i.addEventListener("blocked",c=>n(c.oldVersion,c.newVersion,c)),o.then(c=>{s&&c.addEventListener("close",()=>s()),a&&c.addEventListener("versionchange",l=>a(l.oldVersion,l.newVersion,l))}).catch(()=>{}),o}const Rn=["get","getKey","getAll","getAllKeys","count"],Bn=["put","add","delete","clear"],ae=new Map;function qe(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&typeof t=="string"))return;if(ae.get(t))return ae.get(t);const n=t.replace(/FromIndex$/,""),r=t!==n,a=Bn.includes(n);if(!(n in(r?IDBIndex:IDBObjectStore).prototype)||!(a||Rn.includes(n)))return;const s=async function(i,...o){const c=this.transaction(i,a?"readwrite":"readonly");let l=c.store;return r&&(l=l.index(o.shift())),(await Promise.all([l[n](...o),a&&c.done]))[0]};return ae.set(t,s),s}Cn(e=>({...e,get:(t,n,r)=>qe(t,n)||e.get(t,n,r),has:(t,n)=>!!qe(t,n)||e.has(t,n)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class On{constructor(t){this.container=t}getPlatformInfoString(){return this.container.getProviders().map(n=>{if($n(n)){const r=n.getImmediate();return`${r.library}/${r.version}`}else return null}).filter(n=>n).join(" ")}}function $n(e){const t=e.getComponent();return(t==null?void 0:t.type)==="VERSION"}const ue="@firebase/app",Ge="0.14.6";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const A=new pt("@firebase/app"),Mn="@firebase/app-compat",kn="@firebase/analytics-compat",xn="@firebase/analytics",Pn="@firebase/app-check-compat",Fn="@firebase/app-check",Nn="@firebase/auth",Ln="@firebase/auth-compat",jn="@firebase/database",Hn="@firebase/data-connect",zn="@firebase/database-compat",Vn="@firebase/functions",Un="@firebase/functions-compat",Wn="@firebase/installations",qn="@firebase/installations-compat",Gn="@firebase/messaging",Kn="@firebase/messaging-compat",Jn="@firebase/performance",Yn="@firebase/performance-compat",Xn="@firebase/remote-config",Zn="@firebase/remote-config-compat",Qn="@firebase/storage",er="@firebase/storage-compat",tr="@firebase/firestore",nr="@firebase/ai",rr="@firebase/firestore-compat",ar="firebase";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fe="[DEFAULT]",sr={[ue]:"fire-core",[Mn]:"fire-core-compat",[xn]:"fire-analytics",[kn]:"fire-analytics-compat",[Fn]:"fire-app-check",[Pn]:"fire-app-check-compat",[Nn]:"fire-auth",[Ln]:"fire-auth-compat",[jn]:"fire-rtdb",[Hn]:"fire-data-connect",[zn]:"fire-rtdb-compat",[Vn]:"fire-fn",[Un]:"fire-fn-compat",[Wn]:"fire-iid",[qn]:"fire-iid-compat",[Gn]:"fire-fcm",[Kn]:"fire-fcm-compat",[Jn]:"fire-perf",[Yn]:"fire-perf-compat",[Xn]:"fire-rc",[Zn]:"fire-rc-compat",[Qn]:"fire-gcs",[er]:"fire-gcs-compat",[tr]:"fire-fst",[rr]:"fire-fst-compat",[nr]:"fire-vertex","fire-js":"fire-js",[ar]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const K=new Map,ir=new Map,he=new Map;function Ke(e,t){try{e.container.addComponent(t)}catch(n){A.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,n)}}function M(e){const t=e.name;if(he.has(t))return A.debug(`There were multiple attempts to register component ${t}.`),!1;he.set(t,e);for(const n of K.values())Ke(n,e);for(const n of ir.values())Ke(n,e);return!0}function Z(e,t){const n=e.container.getProvider("heartbeat").getImmediate({optional:!0});return n&&n.triggerHeartbeat(),e.container.getProvider(t)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const or={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},D=new X("app","Firebase",or);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class cr{constructor(t,n,r){this._isDeleted=!1,this._options={...t},this._config={...n},this._name=n.name,this._automaticDataCollectionEnabled=n.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new R("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(t){this.checkDestroyed(),this._automaticDataCollectionEnabled=t}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(t){this._isDeleted=t}checkDestroyed(){if(this.isDeleted)throw D.create("app-deleted",{appName:this._name})}}function yt(e,t={}){let n=e;typeof t!="object"&&(t={name:t});const r={name:fe,automaticDataCollectionEnabled:!0,...t},a=r.name;if(typeof a!="string"||!a)throw D.create("bad-app-name",{appName:String(a)});if(n||(n=ut()),!n)throw D.create("no-options");const s=K.get(a);if(s){if(G(n,s.options)&&G(r,s.config))return s;throw D.create("duplicate-app",{appName:a})}const i=new gn(a);for(const c of he.values())i.addComponent(c);const o=new cr(n,r,i);return K.set(a,o),o}function lr(e=fe){const t=K.get(e);if(!t&&e===fe&&ut())return yt();if(!t)throw D.create("no-app",{appName:e});return t}function v(e,t,n){let r=sr[e]??e;n&&(r+=`-${n}`);const a=r.match(/\s|\//),s=t.match(/\s|\//);if(a||s){const i=[`Unable to register library "${r}" with version "${t}":`];a&&i.push(`library name "${r}" contains illegal characters (whitespace or "/")`),a&&s&&i.push("and"),s&&i.push(`version name "${t}" contains illegal characters (whitespace or "/")`),A.warn(i.join(" "));return}M(new R(`${r}-version`,()=>({library:r,version:t}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const dr="firebase-heartbeat-database",ur=1,j="firebase-heartbeat-store";let se=null;function wt(){return se||(se=bt(dr,ur,{upgrade:(e,t)=>{switch(t){case 0:try{e.createObjectStore(j)}catch(n){console.warn(n)}}}}).catch(e=>{throw D.create("idb-open",{originalErrorMessage:e.message})})),se}async function fr(e){try{const n=(await wt()).transaction(j),r=await n.objectStore(j).get(It(e));return await n.done,r}catch(t){if(t instanceof P)A.warn(t.message);else{const n=D.create("idb-get",{originalErrorMessage:t==null?void 0:t.message});A.warn(n.message)}}}async function Je(e,t){try{const r=(await wt()).transaction(j,"readwrite");await r.objectStore(j).put(t,It(e)),await r.done}catch(n){if(n instanceof P)A.warn(n.message);else{const r=D.create("idb-set",{originalErrorMessage:n==null?void 0:n.message});A.warn(r.message)}}}function It(e){return`${e.name}!${e.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const hr=1024,pr=30;class mr{constructor(t){this.container=t,this._heartbeatsCache=null;const n=this.container.getProvider("app").getImmediate();this._storage=new br(n),this._heartbeatsCachePromise=this._storage.read().then(r=>(this._heartbeatsCache=r,r))}async triggerHeartbeat(){var t,n;try{const a=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),s=Ye();if(((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,((n=this._heartbeatsCache)==null?void 0:n.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===s||this._heartbeatsCache.heartbeats.some(i=>i.date===s))return;if(this._heartbeatsCache.heartbeats.push({date:s,agent:a}),this._heartbeatsCache.heartbeats.length>pr){const i=yr(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(i,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(r){A.warn(r)}}async getHeartbeatsHeader(){var t;try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,((t=this._heartbeatsCache)==null?void 0:t.heartbeats)==null||this._heartbeatsCache.heartbeats.length===0)return"";const n=Ye(),{heartbeatsToSend:r,unsentEntries:a}=gr(this._heartbeatsCache.heartbeats),s=dt(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=n,a.length>0?(this._heartbeatsCache.heartbeats=a,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),s}catch(n){return A.warn(n),""}}}function Ye(){return new Date().toISOString().substring(0,10)}function gr(e,t=hr){const n=[];let r=e.slice();for(const a of e){const s=n.find(i=>i.agent===a.agent);if(s){if(s.dates.push(a.date),Xe(n)>t){s.dates.pop();break}}else if(n.push({agent:a.agent,dates:[a.date]}),Xe(n)>t){n.pop();break}r=r.slice(1)}return{heartbeatsToSend:n,unsentEntries:r}}class br{constructor(t){this.app=t,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return me()?ge().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const n=await fr(this.app);return n!=null&&n.heartbeats?n:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return Je(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:t.heartbeats})}else return}async add(t){if(await this._canUseIndexedDBPromise){const r=await this.read();return Je(this.app,{lastSentHeartbeatDate:t.lastSentHeartbeatDate??r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...t.heartbeats]})}else return}}function Xe(e){return dt(JSON.stringify({version:2,heartbeats:e})).length}function yr(e){if(e.length===0)return-1;let t=0,n=e[0].date;for(let r=1;r<e.length;r++)e[r].date<n&&(n=e[r].date,t=r);return t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wr(e){M(new R("platform-logger",t=>new On(t),"PRIVATE")),M(new R("heartbeat",t=>new mr(t),"PRIVATE")),v(ue,Ge,e),v(ue,Ge,"esm2020"),v("fire-js","")}wr("");var Ir="firebase",Er="12.6.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */v(Ir,Er,"app");const Et="@firebase/installations",we="0.6.19";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const St=1e4,_t=`w:${we}`,At="FIS_v2",Sr="https://firebaseinstallations.googleapis.com/v1",_r=60*60*1e3,Ar="installations",Tr="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cr={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},k=new X(Ar,Tr,Cr);function Tt(e){return e instanceof P&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ct({projectId:e}){return`${Sr}/projects/${e}/installations`}function Dt(e){return{token:e.token,requestStatus:2,expiresIn:vr(e.expiresIn),creationTime:Date.now()}}async function vt(e,t){const r=(await t.json()).error;return k.create("request-failed",{requestName:e,serverCode:r.code,serverMessage:r.message,serverStatus:r.status})}function Rt({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function Dr(e,{refreshToken:t}){const n=Rt(e);return n.append("Authorization",Rr(t)),n}async function Bt(e){const t=await e();return t.status>=500&&t.status<600?e():t}function vr(e){return Number(e.replace("s","000"))}function Rr(e){return`${At} ${e}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Br({appConfig:e,heartbeatServiceProvider:t},{fid:n}){const r=Ct(e),a=Rt(e),s=t.getImmediate({optional:!0});if(s){const l=await s.getHeartbeatsHeader();l&&a.append("x-firebase-client",l)}const i={fid:n,authVersion:At,appId:e.appId,sdkVersion:_t},o={method:"POST",headers:a,body:JSON.stringify(i)},c=await Bt(()=>fetch(r,o));if(c.ok){const l=await c.json();return{fid:l.fid||n,registrationStatus:2,refreshToken:l.refreshToken,authToken:Dt(l.authToken)}}else throw await vt("Create Installation",c)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ot(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Or(e){return btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $r=/^[cdef][\w-]{21}$/,pe="";function Mr(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const n=kr(e);return $r.test(n)?n:pe}catch{return pe}}function kr(e){return Or(e).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Q(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $t=new Map;function Mt(e,t){const n=Q(e);kt(n,t),xr(n,t)}function kt(e,t){const n=$t.get(e);if(n)for(const r of n)r(t)}function xr(e,t){const n=Pr();n&&n.postMessage({key:e,fid:t}),Fr()}let $=null;function Pr(){return!$&&"BroadcastChannel"in self&&($=new BroadcastChannel("[Firebase] FID Change"),$.onmessage=e=>{kt(e.data.key,e.data.fid)}),$}function Fr(){$t.size===0&&$&&($.close(),$=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nr="firebase-installations-database",Lr=1,x="firebase-installations-store";let ie=null;function Ie(){return ie||(ie=bt(Nr,Lr,{upgrade:(e,t)=>{switch(t){case 0:e.createObjectStore(x)}}})),ie}async function J(e,t){const n=Q(e),a=(await Ie()).transaction(x,"readwrite"),s=a.objectStore(x),i=await s.get(n);return await s.put(t,n),await a.done,(!i||i.fid!==t.fid)&&Mt(e,t.fid),t}async function xt(e){const t=Q(e),r=(await Ie()).transaction(x,"readwrite");await r.objectStore(x).delete(t),await r.done}async function ee(e,t){const n=Q(e),a=(await Ie()).transaction(x,"readwrite"),s=a.objectStore(x),i=await s.get(n),o=t(i);return o===void 0?await s.delete(n):await s.put(o,n),await a.done,o&&(!i||i.fid!==o.fid)&&Mt(e,o.fid),o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Ee(e){let t;const n=await ee(e.appConfig,r=>{const a=jr(r),s=Hr(e,a);return t=s.registrationPromise,s.installationEntry});return n.fid===pe?{installationEntry:await t}:{installationEntry:n,registrationPromise:t}}function jr(e){const t=e||{fid:Mr(),registrationStatus:0};return Pt(t)}function Hr(e,t){if(t.registrationStatus===0){if(!navigator.onLine){const a=Promise.reject(k.create("app-offline"));return{installationEntry:t,registrationPromise:a}}const n={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},r=zr(e,n);return{installationEntry:n,registrationPromise:r}}else return t.registrationStatus===1?{installationEntry:t,registrationPromise:Vr(e)}:{installationEntry:t}}async function zr(e,t){try{const n=await Br(e,t);return J(e.appConfig,n)}catch(n){throw Tt(n)&&n.customData.serverCode===409?await xt(e.appConfig):await J(e.appConfig,{fid:t.fid,registrationStatus:0}),n}}async function Vr(e){let t=await Ze(e.appConfig);for(;t.registrationStatus===1;)await Ot(100),t=await Ze(e.appConfig);if(t.registrationStatus===0){const{installationEntry:n,registrationPromise:r}=await Ee(e);return r||n}return t}function Ze(e){return ee(e,t=>{if(!t)throw k.create("installation-not-found");return Pt(t)})}function Pt(e){return Ur(e)?{fid:e.fid,registrationStatus:0}:e}function Ur(e){return e.registrationStatus===1&&e.registrationTime+St<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Wr({appConfig:e,heartbeatServiceProvider:t},n){const r=qr(e,n),a=Dr(e,n),s=t.getImmediate({optional:!0});if(s){const l=await s.getHeartbeatsHeader();l&&a.append("x-firebase-client",l)}const i={installation:{sdkVersion:_t,appId:e.appId}},o={method:"POST",headers:a,body:JSON.stringify(i)},c=await Bt(()=>fetch(r,o));if(c.ok){const l=await c.json();return Dt(l)}else throw await vt("Generate Auth Token",c)}function qr(e,{fid:t}){return`${Ct(e)}/${t}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Se(e,t=!1){let n;const r=await ee(e.appConfig,s=>{if(!Ft(s))throw k.create("not-registered");const i=s.authToken;if(!t&&Jr(i))return s;if(i.requestStatus===1)return n=Gr(e,t),s;{if(!navigator.onLine)throw k.create("app-offline");const o=Xr(s);return n=Kr(e,o),o}});return n?await n:r.authToken}async function Gr(e,t){let n=await Qe(e.appConfig);for(;n.authToken.requestStatus===1;)await Ot(100),n=await Qe(e.appConfig);const r=n.authToken;return r.requestStatus===0?Se(e,t):r}function Qe(e){return ee(e,t=>{if(!Ft(t))throw k.create("not-registered");const n=t.authToken;return Zr(n)?{...t,authToken:{requestStatus:0}}:t})}async function Kr(e,t){try{const n=await Wr(e,t),r={...t,authToken:n};return await J(e.appConfig,r),n}catch(n){if(Tt(n)&&(n.customData.serverCode===401||n.customData.serverCode===404))await xt(e.appConfig);else{const r={...t,authToken:{requestStatus:0}};await J(e.appConfig,r)}throw n}}function Ft(e){return e!==void 0&&e.registrationStatus===2}function Jr(e){return e.requestStatus===2&&!Yr(e)}function Yr(e){const t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+_r}function Xr(e){const t={requestStatus:1,requestTime:Date.now()};return{...e,authToken:t}}function Zr(e){return e.requestStatus===1&&e.requestTime+St<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Qr(e){const t=e,{installationEntry:n,registrationPromise:r}=await Ee(t);return r?r.catch(console.error):Se(t).catch(console.error),n.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ea(e,t=!1){const n=e;return await ta(n),(await Se(n,t)).token}async function ta(e){const{registrationPromise:t}=await Ee(e);t&&await t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function na(e){if(!e||!e.options)throw oe("App Configuration");if(!e.name)throw oe("App Name");const t=["projectId","apiKey","appId"];for(const n of t)if(!e.options[n])throw oe(n);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}function oe(e){return k.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Nt="installations",ra="installations-internal",aa=e=>{const t=e.getProvider("app").getImmediate(),n=na(t),r=Z(t,"heartbeat");return{app:t,appConfig:n,heartbeatServiceProvider:r,_delete:()=>Promise.resolve()}},sa=e=>{const t=e.getProvider("app").getImmediate(),n=Z(t,Nt).getImmediate();return{getId:()=>Qr(n),getToken:a=>ea(n,a)}};function ia(){M(new R(Nt,aa,"PUBLIC")),M(new R(ra,sa,"PRIVATE"))}ia();v(Et,we);v(Et,we,"esm2020");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Y="analytics",oa="firebase_id",ca="origin",la=60*1e3,da="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig",_e="https://www.googletagmanager.com/gtag/js";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const y=new pt("@firebase/analytics");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ua={"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-initialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":"Firebase Analytics Interop Component failed to instantiate: {$reason}","invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":"Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}","no-api-key":'The "apiKey" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.',"no-app-id":'The "appId" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.',"no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":"Trusted Types detected an invalid gtag resource: {$gtagURL}."},I=new X("analytics","Analytics",ua);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fa(e){if(!e.startsWith(_e)){const t=I.create("invalid-gtag-resource",{gtagURL:e});return y.warn(t.message),""}return e}function Lt(e){return Promise.all(e.map(t=>t.catch(n=>n)))}function ha(e,t){let n;return window.trustedTypes&&(n=window.trustedTypes.createPolicy(e,t)),n}function pa(e,t){const n=ha("firebase-js-sdk-policy",{createScriptURL:fa}),r=document.createElement("script"),a=`${_e}?l=${e}&id=${t}`;r.src=n?n==null?void 0:n.createScriptURL(a):a,r.async=!0,document.head.appendChild(r)}function ma(e){let t=[];return Array.isArray(window[e])?t=window[e]:window[e]=t,t}async function ga(e,t,n,r,a,s){const i=r[a];try{if(i)await t[i];else{const c=(await Lt(n)).find(l=>l.measurementId===a);c&&await t[c.appId]}}catch(o){y.error(o)}e("config",a,s)}async function ba(e,t,n,r,a){try{let s=[];if(a&&a.send_to){let i=a.send_to;Array.isArray(i)||(i=[i]);const o=await Lt(n);for(const c of i){const l=o.find(u=>u.measurementId===c),h=l&&t[l.appId];if(h)s.push(h);else{s=[];break}}}s.length===0&&(s=Object.values(t)),await Promise.all(s),e("event",r,a||{})}catch(s){y.error(s)}}function ya(e,t,n,r){async function a(s,...i){try{if(s==="event"){const[o,c]=i;await ba(e,t,n,o,c)}else if(s==="config"){const[o,c]=i;await ga(e,t,n,r,o,c)}else if(s==="consent"){const[o,c]=i;e("consent",o,c)}else if(s==="get"){const[o,c,l]=i;e("get",o,c,l)}else if(s==="set"){const[o]=i;e("set",o)}else e(s,...i)}catch(o){y.error(o)}}return a}function wa(e,t,n,r,a){let s=function(...i){window[r].push(arguments)};return window[a]&&typeof window[a]=="function"&&(s=window[a]),window[a]=ya(s,e,t,n),{gtagCore:s,wrappedGtag:window[a]}}function Ia(e){const t=window.document.getElementsByTagName("script");for(const n of Object.values(t))if(n.src&&n.src.includes(_e)&&n.src.includes(e))return n;return null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ea=30,Sa=1e3;class _a{constructor(t={},n=Sa){this.throttleMetadata=t,this.intervalMillis=n}getThrottleMetadata(t){return this.throttleMetadata[t]}setThrottleMetadata(t,n){this.throttleMetadata[t]=n}deleteThrottleMetadata(t){delete this.throttleMetadata[t]}}const jt=new _a;function Aa(e){return new Headers({Accept:"application/json","x-goog-api-key":e})}async function Ta(e){var i;const{appId:t,apiKey:n}=e,r={method:"GET",headers:Aa(n)},a=da.replace("{app-id}",t),s=await fetch(a,r);if(s.status!==200&&s.status!==304){let o="";try{const c=await s.json();(i=c.error)!=null&&i.message&&(o=c.error.message)}catch{}throw I.create("config-fetch-failed",{httpStatus:s.status,responseMessage:o})}return s.json()}async function Ca(e,t=jt,n){const{appId:r,apiKey:a,measurementId:s}=e.options;if(!r)throw I.create("no-app-id");if(!a){if(s)return{measurementId:s,appId:r};throw I.create("no-api-key")}const i=t.getThrottleMetadata(r)||{backoffCount:0,throttleEndTimeMillis:Date.now()},o=new Ra;return setTimeout(async()=>{o.abort()},la),Ht({appId:r,apiKey:a,measurementId:s},i,o,t)}async function Ht(e,{throttleEndTimeMillis:t,backoffCount:n},r,a=jt){var o;const{appId:s,measurementId:i}=e;try{await Da(r,t)}catch(c){if(i)return y.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${i} provided in the "measurementId" field in the local Firebase config. [${c==null?void 0:c.message}]`),{appId:s,measurementId:i};throw c}try{const c=await Ta(e);return a.deleteThrottleMetadata(s),c}catch(c){const l=c;if(!va(l)){if(a.deleteThrottleMetadata(s),i)return y.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${i} provided in the "measurementId" field in the local Firebase config. [${l==null?void 0:l.message}]`),{appId:s,measurementId:i};throw c}const h=Number((o=l==null?void 0:l.customData)==null?void 0:o.httpStatus)===503?Ve(n,a.intervalMillis,Ea):Ve(n,a.intervalMillis),u={throttleEndTimeMillis:Date.now()+h,backoffCount:n+1};return a.setThrottleMetadata(s,u),y.debug(`Calling attemptFetch again in ${h} millis`),Ht(e,u,r,a)}}function Da(e,t){return new Promise((n,r)=>{const a=Math.max(t-Date.now(),0),s=setTimeout(n,a);e.addEventListener(()=>{clearTimeout(s),r(I.create("fetch-throttle",{throttleEndTimeMillis:t}))})})}function va(e){if(!(e instanceof P)||!e.customData)return!1;const t=Number(e.customData.httpStatus);return t===429||t===500||t===503||t===504}class Ra{constructor(){this.listeners=[]}addEventListener(t){this.listeners.push(t)}abort(){this.listeners.forEach(t=>t())}}async function Ba(e,t,n,r,a){if(a&&a.global){e("event",n,r);return}else{const s=await t,i={...r,send_to:s};e("event",n,i)}}async function Oa(e,t,n,r){if(r&&r.global){const a={};for(const s of Object.keys(n))a[`user_properties.${s}`]=n[s];return e("set",a),Promise.resolve()}else{const a=await t;e("config",a,{update:!0,user_properties:n})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $a(){if(me())try{await ge()}catch(e){return y.warn(I.create("indexeddb-unavailable",{errorInfo:e==null?void 0:e.toString()}).message),!1}else return y.warn(I.create("indexeddb-unavailable",{errorInfo:"IndexedDB is not available in this environment."}).message),!1;return!0}async function Ma(e,t,n,r,a,s,i){const o=Ca(e);o.then(m=>{n[m.measurementId]=m.appId,e.options.measurementId&&m.measurementId!==e.options.measurementId&&y.warn(`The measurement ID in the local Firebase config (${e.options.measurementId}) does not match the measurement ID fetched from the server (${m.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(m=>y.error(m)),t.push(o);const c=$a().then(m=>{if(m)return r.getId()}),[l,h]=await Promise.all([o,c]);Ia(s)||pa(s,l.measurementId),a("js",new Date);const u=(i==null?void 0:i.config)??{};return u[ca]="firebase",u.update=!0,h!=null&&(u[oa]=h),a("config",l.measurementId,u),l.measurementId}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ka{constructor(t){this.app=t}_delete(){return delete L[this.app.options.appId],Promise.resolve()}}let L={},et=[];const tt={};let ce="dataLayer",xa="gtag",nt,Ae,rt=!1;function Pa(){const e=[];if(ft()&&e.push("This is a browser extension environment."),ht()||e.push("Cookies are not available."),e.length>0){const t=e.map((r,a)=>`(${a+1}) ${r}`).join(" "),n=I.create("invalid-analytics-context",{errorInfo:t});y.warn(n.message)}}function Fa(e,t,n){Pa();const r=e.options.appId;if(!r)throw I.create("no-app-id");if(!e.options.apiKey)if(e.options.measurementId)y.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${e.options.measurementId} provided in the "measurementId" field in the local Firebase config.`);else throw I.create("no-api-key");if(L[r]!=null)throw I.create("already-exists",{id:r});if(!rt){ma(ce);const{wrappedGtag:s,gtagCore:i}=wa(L,et,tt,ce,xa);Ae=s,nt=i,rt=!0}return L[r]=Ma(e,et,tt,t,nt,ce,n),new ka(e)}function Na(e=lr()){e=be(e);const t=Z(e,Y);return t.isInitialized()?t.getImmediate():La(e)}function La(e,t={}){const n=Z(e,Y);if(n.isInitialized()){const a=n.getImmediate();if(G(t,n.getOptions()))return a;throw I.create("already-initialized")}return n.initialize({options:t})}async function ja(){if(ft()||!ht()||!me())return!1;try{return await ge()}catch{return!1}}function Ha(e,t,n){e=be(e),Oa(Ae,L[e.app.options.appId],t,n).catch(r=>y.error(r))}function za(e,t,n,r){e=be(e),Ba(Ae,L[e.app.options.appId],t,n,r).catch(a=>y.error(a))}const at="@firebase/analytics",st="0.10.19";function Va(){M(new R(Y,(t,{options:n})=>{const r=t.getProvider("app").getImmediate(),a=t.getProvider("installations-internal").getImmediate();return Fa(r,a,n)},"PUBLIC")),M(new R("analytics-internal",e,"PRIVATE")),v(at,st),v(at,st,"esm2020");function e(t){try{const n=t.getProvider(Y).getImmediate();return{logEvent:(r,a,s)=>za(n,r,a,s),setUserProperties:(r,a)=>Ha(n,r,a)}}catch(n){throw I.create("interop-component-reg-failed",{reason:n})}}}Va();const Ua={apiKey:"AIzaSyDhSJgpTCdgDefG76DlieEKXBpWVKtJBuk",authDomain:"twitch-hyper-timer.firebaseapp.com",projectId:"twitch-hyper-timer",storageBucket:"twitch-hyper-timer.firebasestorage.app",messagingSenderId:"403335558740",appId:"1:403335558740:web:d97c786c33f2d7c5eddfc1",measurementId:"G-KDPR1FNLPJ"},Wa=yt(Ua);let q=null;async function qa(){if(typeof window>"u")return null;if(q)return q;try{return await ja()?(q=Na(Wa),q):null}catch{return null}}const it="https://twitch-timer-extension.fly.dev",ot={sound_10:"10",sound_25:"25",sound_50:"50",sound_75:"75",sound_100:"100",sound_150:"150",sound_200:"200",sound_300:"300",sound_500:"500",sound_1000:"1000"};function Ga(){const[e,t]=w.useState(0),[n,r]=w.useState(!1),a=w.useRef(),s=w.useRef(null),[i,o]=w.useState([]),[c,l]=w.useState(!1),[h,u]=w.useState(!1),[m,F]=w.useState([]),N=w.useRef(null),[Te,zt]=w.useState({}),[Ce,H]=w.useState(null),De=w.useCallback((f,E)=>{fetch(`${it}/api/sounds/public?channelId=${E}`,{headers:{Authorization:`Bearer ${f}`}}).then(g=>g.json()).then(g=>{var B;o(g.sounds||[]),l(((B=g.settings)==null?void 0:B.enabled)??!1)}).catch(()=>{})},[]);w.useEffect(()=>{var E,g,B,ve,z,Re,Be,Oe,V,$e,Me,U,ke;qa(),(g=(E=window.Twitch)==null?void 0:E.ext)==null||g.onAuthorized(S=>{var _,T,b,xe,Pe,W,Fe;s.current=S,(b=(T=(_=window.Twitch)==null?void 0:_.ext)==null?void 0:T.features)!=null&&b.isBitsEnabled&&(u(!0),window.Twitch.ext.bits.getProducts().then(te=>F(te)).catch(()=>{})),(Fe=(W=(Pe=(xe=window.Twitch)==null?void 0:xe.ext)==null?void 0:Pe.features)==null?void 0:W.onChanged)==null||Fe.call(W,te=>{var Ne,Le,je;te.includes("isBitsEnabled")&&u(!!((je=(Le=(Ne=window.Twitch)==null?void 0:Ne.ext)==null?void 0:Le.features)!=null&&je.isBitsEnabled))}),De(S.token,S.channelId)}),(Re=(z=(ve=(B=window.Twitch)==null?void 0:B.ext)==null?void 0:ve.bits)==null?void 0:z.onTransactionComplete)==null||Re.call(z,S=>{const _=N.current,T=s.current;_&&T&&(fetch(`${it}/api/sounds/redeem`,{method:"POST",headers:{Authorization:`Bearer ${T.token}`,"Content-Type":"application/json"},body:JSON.stringify({receipt:S.transactionReceipt,soundId:_.id,channelId:T.channelId})}).then(()=>{zt(b=>({...b,[_.id]:Date.now()+(_.cooldownMs||5e3)})),H(_.name),setTimeout(()=>H(null),3e3)}).catch(()=>{}),N.current=null)}),($e=(V=(Oe=(Be=window.Twitch)==null?void 0:Be.ext)==null?void 0:Oe.bits)==null?void 0:V.onTransactionCancelled)==null||$e.call(V,()=>{N.current=null}),(ke=(U=(Me=window.Twitch)==null?void 0:Me.ext)==null?void 0:U.listen)==null||ke.call(U,"broadcast",(S,_,T)=>{try{const b=JSON.parse(T);b.type==="timer_reset"||b.type==="timer_tick"?(t(b.payload.remaining??0),typeof b.payload.hype<"u"&&r(!!b.payload.hype)):b.type==="timer_add"?(t(b.payload.newRemaining??0),r(!!b.payload.hype)):b.type==="sound_alert"&&(H(b.payload.soundName||"Sound"),setTimeout(()=>H(null),3e3))}catch{}});const f=()=>{t(S=>S>0?S-1:0),a.current=setTimeout(f,1e3)};return f(),()=>clearTimeout(a.current)},[De]);function Vt(f){h&&(N.current=f,window.Twitch.ext.bits.useBits(f.tier))}function Ut(f){var g;const E=m.find(B=>B.sku===f);return E?((g=E.cost)==null?void 0:g.amount)||ot[f]||"?":ot[f]||"?"}const Wt=String(Math.floor(e/60)).padStart(2,"0"),qt=String(e%60).padStart(2,"0");return p.jsxs("div",{style:{padding:12},children:[p.jsxs("div",{style:{padding:16,borderRadius:16,background:"#1f1f23",boxShadow:"0 0 0 1px #303038 inset"},children:[p.jsx("div",{style:{fontSize:18,opacity:.85},children:"Stream Countdown"}),p.jsxs("div",{style:{fontFamily:"monospace",fontSize:64,lineHeight:1,marginTop:8},children:[Wt,":",qt]}),n&&p.jsx("div",{style:{marginTop:8,padding:"6px 10px",borderRadius:999,display:"inline-block",background:"#9146FF22",boxShadow:"0 0 0 1px #9146FF inset",fontSize:12},children:"🔥 Hype Train active — time gains doubled!"})]}),c&&i.length>0&&p.jsx("div",{style:{marginTop:12},children:p.jsxs("div",{style:{padding:14,borderRadius:16,background:"#1f1f23",boxShadow:"0 0 0 1px #303038 inset"},children:[p.jsx("div",{style:{fontSize:15,opacity:.85,marginBottom:8},children:"Sound Alerts"}),Ce&&p.jsxs("div",{style:{padding:"6px 10px",borderRadius:8,background:"#9146FF22",border:"1px solid #9146FF44",fontSize:12,marginBottom:8,textAlign:"center"},children:["🔊 ",Ce]}),!h&&p.jsx("div",{style:{fontSize:12,opacity:.5,marginBottom:6},children:"Bits are not available on this channel."}),p.jsx("div",{style:{display:"flex",flexDirection:"column",gap:4},children:i.map(f=>{const E=Te[f.id]&&Date.now()<Te[f.id],g=!h||E;return p.jsxs("button",{disabled:g,onClick:()=>Vt(f),style:{display:"flex",justifyContent:"space-between",alignItems:"center",width:"100%",padding:"8px 12px",background:g?"#16161a":"#2a2a32",border:"1px solid #303038",borderRadius:8,color:"#efeff1",cursor:g?"not-allowed":"pointer",opacity:g?.5:1,fontSize:13,transition:"background 0.15s"},children:[p.jsx("span",{style:{fontWeight:600},children:f.name}),p.jsxs("span",{style:{fontSize:12,opacity:.7,display:"flex",alignItems:"center",gap:4},children:[p.jsx("span",{style:{display:"inline-block",width:12,height:12,borderRadius:"50%",background:"linear-gradient(135deg, #9146FF, #772CE8)"}}),Ut(f.tier)]})]},f.id)})})]})})]})}Gt.createRoot(document.getElementById("root")).render(p.jsx(Ga,{}));
